"""
common/collision.py -- Mo hinh va cham EDCA (Sec. III.A).

Tai hien he diem co dinh:
  Eq.(4)  c_k = sum_j [pi_j / sum_i pi_i] (1 - (prod_l r_l^{n_l}) / r_k)
  Eq.(5)  p_k = 2 / (eta_k * sum_{j=0}^{R_k-1} c_k^j (f_{k,j} - 1))
          voi eta_k = (1 - c_k) (1 - c_k^{R_k})^{-1},
              f_{k,j} = 2^{min(j, m_k)} CW_min,k,  m_k = log2(CW_max,k/CW_min,k)
  Eq.(6)  P_loss,k = c_k^{R_k}

He (3)-(5) duoc giai lap cho tung LINK (cac AC tren cung mot link tranh chap
voi nhau; cac link doc lap ve tan so nen giai rieng).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Sequence

import numpy as np

from common.zones import (ZoneModel, build_zone_model, zone_idle_prob,
                          zone_stationary)
from config import EDCAParams

EPS = 1e-300


@dataclass
class LinkState:
    """Nghiem diem co dinh cua mot link (theo THU TU SAP XEP AIFS tang dan)."""

    zm: ZoneModel
    n_sta: np.ndarray          # (I,) so tram cua tung AC
    p: np.ndarray              # (I,) p_k -- xac suat phat trong mot slot
    r: np.ndarray              # (I,) r_k = 1 - p_k
    c: np.ndarray              # (I,) c_k -- xac suat va cham
    q: np.ndarray              # (J,) q_j -- xac suat khong ai phat trong vung j
    pi: np.ndarray             # (J,) pi_j
    p_loss: np.ndarray         # (I,) P_loss,k = c_k^{R_k}
    retry: np.ndarray          # (I,) R_k
    cw_min: np.ndarray         # (I,) CW_min,k
    cw_max: np.ndarray         # (I,) CW_max,k
    converged: bool
    n_iter: int

    def cw_at_stage(self, k: int, j: int) -> float:
        """f_{k,j} = 2^{min(j, m_k)} CW_min,k -- kich thuoc cua so o buoc backoff j."""
        m_k = np.log2(max(self.cw_max[k] / max(self.cw_min[k], 1), 1.0))
        return float(2 ** min(j, m_k) * self.cw_min[k])

    def cw_stages(self, k: int) -> np.ndarray:
        """Vector f_{k,j}, j = 0..R_k-1."""
        return np.array([self.cw_at_stage(k, j) for j in range(int(self.retry[k]))])


# ---------------------------------------------------------------------------
# Eq. (5): p_k tu c_k
# ---------------------------------------------------------------------------


def transmit_prob(c_k: float, cw_min: float, cw_max: float, retry: int) -> float:
    """Eq.(5) -- xap xi gia tri trung binh cua xac suat phat."""
    c_k = float(np.clip(c_k, 0.0, 1.0 - 1e-12))
    m_k = np.log2(max(cw_max / max(cw_min, 1.0), 1.0))
    j = np.arange(retry)
    f = 2.0 ** np.minimum(j, m_k) * cw_min
    eta = (1.0 - c_k) / (1.0 - c_k ** retry) if c_k > 0 else 1.0
    denom = eta * np.sum(c_k ** j * (f - 1.0))
    if denom <= 0:
        return 1.0
    return float(np.clip(2.0 / denom, 1e-12, 1.0))


# ---------------------------------------------------------------------------
# Eq. (4): c_k tu p
# ---------------------------------------------------------------------------


def collision_prob(zm: ZoneModel, r: np.ndarray, n_sta: np.ndarray,
                   q: np.ndarray, pi: np.ndarray) -> np.ndarray:
    """Eq.(4) -- xac suat va cham cua tung AC (thu tu da sap xep)."""
    c = np.zeros(zm.n_ac)
    for k in range(zm.n_ac):
        j0 = zm.zone_of_ac[k]
        w = pi[j0:]
        s = w.sum()
        if s <= 0:
            c[k] = 0.0
            continue
        # 1 - q_j / r_k : xac suat co it nhat mot tram KHAC phat trong vung j
        others_idle = q[j0:] / max(r[k], EPS)
        c[k] = float(np.dot(w / s, 1.0 - np.clip(others_idle, 0.0, 1.0)))
    return np.clip(c, 0.0, 1.0 - 1e-12)


# ---------------------------------------------------------------------------
# Giai he diem co dinh (3)-(5)
# ---------------------------------------------------------------------------


def solve_link(params: Sequence[EDCAParams], n_sta: Sequence[int],
               tol: float = 1e-12, max_iter: int = 500,
               damping: float = 0.5) -> LinkState:
    """Giai he diem co dinh cho cac AC dang hoat dong tren MOT link.

    params : danh sach EDCAParams cua cac AC tren link (theo thu tu goc)
    n_sta  : so tram tuong ung
    """
    aifs = [pp.aifs_us for pp in params]
    zm = build_zone_model(aifs)
    o = zm.order                                     # sap xep theo AIFS tang dan

    n = np.array([n_sta[i] for i in o], dtype=float)
    cw_min = np.array([params[i].cw_min for i in o], dtype=float)
    cw_max = np.array([max(params[i].cw_max, params[i].cw_min) for i in o], dtype=float)
    retry = np.array([params[i].retry for i in o], dtype=int)

    p = np.array([transmit_prob(0.0, cw_min[k], cw_max[k], retry[k])
                  for k in range(len(o))])
    converged, it = False, 0

    for it in range(1, max_iter + 1):
        r = 1.0 - p
        q = zone_idle_prob(zm, r, n)
        pi = zone_stationary(zm, q)
        c = collision_prob(zm, r, n, q, pi)
        p_new = np.array([transmit_prob(c[k], cw_min[k], cw_max[k], retry[k])
                          for k in range(len(o))])
        p_next = damping * p_new + (1.0 - damping) * p
        if np.max(np.abs(p_next - p)) < tol:
            p = p_next
            converged = True
            break
        p = p_next

    r = 1.0 - p
    q = zone_idle_prob(zm, r, n)
    pi = zone_stationary(zm, q)
    c = collision_prob(zm, r, n, q, pi)
    p_loss = c ** retry                                # Eq.(6)

    return LinkState(zm=zm, n_sta=n, p=p, r=r, c=c, q=q, pi=pi,
                     p_loss=p_loss, retry=retry, cw_min=cw_min, cw_max=cw_max,
                     converged=converged, n_iter=it)


if __name__ == "__main__":
    from config import DEFAULT_EDCA, AC_SET

    st = solve_link(DEFAULT_EDCA, [a.n_sta for a in AC_SET])
    names = [AC_SET[i].name for i in st.zm.order]
    print(f"hoi tu: {st.converged} sau {st.n_iter} vong lap")
    print(f"{'AC':>5} {'AIFS':>7} {'p':>9} {'c':>9} {'P_loss':>11}")
    for k, nm in enumerate(names):
        print(f"{nm:>5} {st.zm.aifs_us[k]:7.0f} {st.p[k]:9.5f} {st.c[k]:9.5f} "
              f"{st.p_loss[k]:11.3e}")
