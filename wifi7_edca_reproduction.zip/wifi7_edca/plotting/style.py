"""
plotting/style.py -- He mau va cau hinh chung cho tat ca cac hinh.

Bang mau phan loai da qua kiem chung: nam trong dai do sang L 0.43-0.77,
chroma >= 0.1, khoang cach nho nhat giua cac cap ke nhau voi nguoi mu mau
dE = 9.1 (protan). Mau duoc gan CO DINH theo thuc the (AC / cau hinh), khong
xoay vong theo thu tu ve.
"""
from __future__ import annotations

import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from config import FIG_DIR

SERIES = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4"]

SURFACE = "#fcfcfb"
INK = "#0b0b0b"
INK_2 = "#52514e"
MUTED = "#898781"
GRID = "#e1e0d9"
AXIS = "#c3c2b7"

# Mau co dinh cho tung cau hinh (Fig. 5, Fig. 6)
CONFIG_COLOR = {
    "Default EDCA": MUTED,
    "Opt. EDCA": SERIES[1],
    "Opt. MLO EDCA": SERIES[0],
    "EDCA": SERIES[1],
    "MLO EDCA": SERIES[0],
    "Target eps": SERIES[2],
}

# Mau co dinh cho tung AC (Fig. 3)
AC_COLOR = {f"AC{i+1}": SERIES[i] for i in range(5)}

MARKERS = ["o", "s", "^", "D", "v"]


def apply_style() -> None:
    plt.rcParams.update({
        "figure.facecolor": SURFACE,
        "axes.facecolor": SURFACE,
        "savefig.facecolor": SURFACE,
        "axes.edgecolor": AXIS,
        "axes.labelcolor": INK,
        "axes.titlecolor": INK,
        "axes.titlesize": 11,
        "axes.titleweight": "600",
        "axes.labelsize": 9.5,
        "axes.grid": True,
        "axes.axisbelow": True,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "grid.color": GRID,
        "grid.linewidth": 0.7,
        "xtick.color": MUTED,
        "ytick.color": MUTED,
        "xtick.labelsize": 8.5,
        "ytick.labelsize": 8.5,
        "text.color": INK,
        "legend.frameon": False,
        "legend.fontsize": 8.5,
        "lines.linewidth": 2.0,
        "lines.markersize": 5.0,
        "font.family": "DejaVu Sans",
        "figure.dpi": 130,
    })


def save(fig, name: str) -> str:
    os.makedirs(FIG_DIR, exist_ok=True)
    path = os.path.join(FIG_DIR, f"{name}.png")
    fig.savefig(path, bbox_inches="tight", dpi=190)
    plt.close(fig)
    return path


def annotate(ax, text: str, loc: str = "upper left") -> None:
    xy = {"upper left": (0.02, 0.97), "upper right": (0.98, 0.97),
          "lower left": (0.02, 0.04), "lower right": (0.98, 0.04)}[loc]
    ha = "left" if "left" in loc else "right"
    va = "top" if "upper" in loc else "bottom"
    ax.text(*xy, text, transform=ax.transAxes, ha=ha, va=va,
            fontsize=8, color=INK_2)
