"""
plotting/figures.py -- MODULE VE KET QUA.

Moi ham `plot_figX(data)` nhan dict do `training/experiments.py` sinh ra va
xuat file PNG vao thu muc `figures/`. Module nay KHONG tinh toan lai gi.

Nguyen tac trinh bay:
  - mau gan co dinh theo thuc the (AC / cau hinh), khong xoay vong
  - khong dung hai truc y tren cung mot o ve; dai luong khac thang do duoc
    tach thanh cac o ve rieng dung chung truc x
  - luon co legend khi >= 2 series
"""
from __future__ import annotations

from typing import Dict

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.lines import Line2D

from plotting.style import (AC_COLOR, CONFIG_COLOR, GRID, INK_2, MARKERS,
                            MUTED, SERIES, annotate, apply_style, save)

apply_style()


# ===========================================================================
# Fig. 2 -- mo hinh vung AIFS
# ===========================================================================


def plot_fig2(d: Dict) -> str:
    n = d["n_slots"]
    fig, ax = plt.subplots(figsize=(8.4, 3.4))

    rows = [("$\\varphi_j$", d["phi"]),
            ("$Z_j$", [d["z_count"][z] for z in d["zone_of_slot"]]),
            ("Slot", list(range(1, n + 1))),
            ("Zone", [z + 1 for z in d["zone_of_slot"]])]

    for r, (label, values) in enumerate(rows):
        y = len(rows) - r - 1
        for i, v in enumerate(values):
            color = (SERIES[d["zone_of_slot"][i] % len(SERIES)]
                     if label == "Zone" else "white")
            ax.add_patch(plt.Rectangle((i, y), 1, 0.9, facecolor=color,
                                       edgecolor=INK_2, linewidth=0.8,
                                       alpha=0.35 if label == "Zone" else 1.0))
            ax.text(i + 0.5, y + 0.45, str(v), ha="center", va="center",
                    fontsize=9)
        ax.text(-0.25, y + 0.45, label, ha="right", va="center", fontsize=9.5,
                color=INK_2)

    # danh dau slot ma tung AC bat dau duoc tranh chap (gop cac AC cung AIFS)
    by_offset: Dict[int, list] = {}
    for k, h in enumerate(d["h"]):
        by_offset.setdefault(int(h), []).append(k + 1)
    for h, ks in by_offset.items():
        label = ("AIFS$_{" + ",".join(str(k) for k in ks) + "}$"
                 + f" (AIFSN={d['aifsn'][ks[0] - 1]})")
        ax.annotate(label, xy=(h + 0.5, len(rows)),
                    xytext=(h + 0.5, len(rows) + 0.45),
                    ha="center", fontsize=8, color=INK_2,
                    arrowprops=dict(arrowstyle="->", color=INK_2, lw=0.9))

    ax.set_xlim(-0.1, n)
    ax.set_ylim(0, len(rows) + 1.1)
    ax.axis("off")
    ax.set_title("Fig. 2 -- Mo hinh vung AIFS: cac AC co AIFS lon hon chi bat dau "
                 "dem lui tu vung sau\n"
                 f"$Z_j$ = {d['z_count']}   |   $\\pi_j$ = "
                 f"{np.round(d['pi'], 3).tolist()}")
    return save(fig, "fig02_aifs_zone_model")


# ===========================================================================
# Fig. 3 -- do nhay tham so
# ===========================================================================


def plot_fig3(d: Dict) -> str:
    aifsn2 = np.array(d["aifsn2"])
    txop2 = np.array(d["txop2"])
    th1 = np.array(d["theta_ac1"])
    th2 = np.array(d["theta_ac2"])

    fig = plt.figure(figsize=(12.6, 4.2))
    gs = fig.add_gridspec(1, 3, width_ratios=[1.25, 1.0, 1.0], wspace=0.42)

    # --- (a) mat 3D nhu Fig. 3a cua paper ---------------------------------
    ax = fig.add_subplot(gs[0, 0], projection="3d")
    X, Y = np.meshgrid(txop2, aifsn2)
    ax.plot_surface(Y, X, th1, color=AC_COLOR["AC1"], alpha=0.75,
                    linewidth=0, antialiased=True, shade=True)
    ax.plot_surface(Y, X, th2, color=AC_COLOR["AC2"], alpha=0.75,
                    linewidth=0, antialiased=True, shade=True)
    ax.set_xlabel("AIFSN$_2$", fontsize=9)
    ax.set_ylabel("TXOP$_2$ ($\\mu$s)", fontsize=9)
    ax.set_zlabel("$\\theta$", fontsize=9)
    ax.set_title(f"(a) Chi so tin cay tre $\\theta$\n"
                 f"AC$_1$ co dinh: AIFSN = {d['aifsn1']}, "
                 f"TXOP = {d['txop1']:.0f} $\\mu$s", fontsize=10)
    ax.view_init(elev=22, azim=-125)
    ax.legend(handles=[Line2D([], [], color=AC_COLOR["AC1"], lw=6,
                              label="AC$_1$ (co dinh)"),
                       Line2D([], [], color=AC_COLOR["AC2"], lw=6,
                              label="AC$_2$ (thay doi)")],
              loc="upper left", fontsize=8)

    # --- (a') lat cat dang ban do nhiet cho de doc -------------------------
    ax2 = fig.add_subplot(gs[0, 1])
    diff = th2 - th1
    lim = float(np.max(np.abs(diff)))
    im = ax2.pcolormesh(aifsn2, txop2, diff.T, cmap="RdBu", vmin=-lim, vmax=lim,
                        shading="nearest")
    cs = ax2.contour(aifsn2, txop2, diff.T, levels=[0.0], colors=[INK_2],
                     linewidths=1.4)
    ax2.clabel(cs, fmt={0.0: "$\\theta_2=\\theta_1$"}, fontsize=8)
    cb = fig.colorbar(im, ax=ax2, pad=0.02)
    cb.set_label("$\\theta_2 - \\theta_1$", fontsize=9)
    ax2.set_xlabel("AIFSN$_2$")
    ax2.set_ylabel("TXOP$_2$ ($\\mu$s)")
    ax2.set_title("(a') Chenh lech $\\theta_2-\\theta_1$\n(do = AC$_2$ tot hon)",
                  fontsize=10)

    # --- (b) P_loss theo AIFSN_2 ------------------------------------------
    ax3 = fig.add_subplot(gs[0, 2])
    ax3.semilogy(aifsn2, d["ploss_ac1"], marker=MARKERS[0],
                 color=AC_COLOR["AC1"], label="AC$_1$ (co dinh)",
                 markeredgecolor="white", markeredgewidth=0.7)
    ax3.semilogy(aifsn2, d["ploss_ac2"], marker=MARKERS[1],
                 color=AC_COLOR["AC2"], label="AC$_2$ (thay doi)",
                 markeredgecolor="white", markeredgewidth=0.7)
    ax3.axvline(d["aifsn1"], color=MUTED, linestyle=":", linewidth=1.2)
    ax3.annotate("AIFSN$_2$ = AIFSN$_1$", xy=(d["aifsn1"], ax3.get_ylim()[1]),
                 xytext=(3, -12), textcoords="offset points", fontsize=8,
                 color=INK_2)
    ax3.set_xlabel("AIFSN$_2$")
    ax3.set_ylabel("Packet Loss Rate $P_{loss}$")
    ax3.set_title("(b) Xac suat mat goi", fontsize=10)
    ax3.grid(True, which="both", color=GRID, linewidth=0.6)
    ax3.legend(loc="center left")

    fig.suptitle("Fig. 3 -- Do nhay cua EDCA voi AIFS va TXOP", fontsize=11,
                 y=1.02)
    return save(fig, "fig03_parameter_sensitivity")


# ===========================================================================
# Fig. 4 -- hoi tu cua GA
# ===========================================================================


def plot_fig4(d: Dict) -> str:
    hist = d["history"]
    fig, axes = plt.subplots(1, 2, figsize=(11.0, 4.2))

    for tag in ("EDCA", "MLO EDCA"):
        h = hist[tag]
        gen = np.arange(len(h["best"]))
        color = CONFIG_COLOR[tag]
        axes[0].plot(gen, h["best"], color=color, label=f"{tag} -- tot nhat")
        mf = np.array(h["mean_feasible"], dtype=float)
        axes[0].plot(gen, mf, "--", color=color, linewidth=1.4,
                     label=f"{tag} -- trung binh (ca the kha thi)")
        axes[1].plot(gen, np.array(h["frac_feasible"]) * 100, color=color,
                     label=tag)

    axes[0].set_xlabel("The he (generation)")
    axes[0].set_ylabel("Gia tri thich nghi  $\\sum_i -\\log_{10} P_{loss,i}$")
    axes[0].set_title("(a) Hoi tu cua ham thich nghi\n"
                      "(truoc khi tim duoc ca the kha thi, gia tri nam duoi khung)")
    axes[0].legend(loc="upper left", bbox_to_anchor=(0.02, 0.84))
    vals = [v for h in hist.values() for v in h["best"] + h["mean_feasible"]
            if v is not None and v == v and v > -500]
    axes[0].set_ylim(min(vals) - 1.0, max(vals) + 2.5)

    axes[1].set_xlabel("The he (generation)")
    axes[1].set_ylabel("Ty le ca the kha thi (%)")
    axes[1].set_title("(b) Ty le ca the thoa man moi rang buoc tre")
    axes[1].legend(loc="upper left")

    n_ev = {k: hist[k]["n_eval"] for k in hist}
    annotate(axes[0], f"so lan danh gia: EDCA {n_ev['EDCA']}, "
                      f"MLO {n_ev['MLO EDCA']}", "upper left")
    fig.suptitle("Fig. 4 -- Hoi tu cua thuat toan di truyen cho MLO EDCA va "
                 "EDCA don link", fontsize=11, y=1.0)
    fig.tight_layout()
    return save(fig, "fig04_ga_convergence")


# ===========================================================================
# Fig. 5 -- so sanh QoS ba cau hinh
# ===========================================================================


def plot_fig5(d: Dict) -> str:
    names = d["ac_names"]
    eps = np.array(d["epsilon"])
    order = ["Default EDCA", "Opt. EDCA", "Opt. MLO EDCA"]
    x = np.arange(len(names))
    w = 0.26

    fig, axes = plt.subplots(1, 2, figsize=(11.6, 4.2))

    for k, name in enumerate(order):
        cfg = d["configs"][name]
        axes[0].bar(x + (k - 1) * w, cfg["violation"], w,
                    color=CONFIG_COLOR[name], label=name,
                    edgecolor="white", linewidth=0.8)
        axes[1].bar(x + (k - 1) * w, cfg["p_loss"], w,
                    color=CONFIG_COLOR[name], label=name,
                    edgecolor="white", linewidth=0.8)

    # nguong muc tieu eps_i
    for i, e in enumerate(eps):
        axes[0].plot([x[i] - 1.6 * w, x[i] + 1.6 * w], [e, e],
                     color=CONFIG_COLOR["Target eps"], linewidth=2.0,
                     solid_capstyle="butt",
                     label="Muc tieu $\\epsilon_i$" if i == 0 else None)

    for ax, ylab, title in (
            (axes[0], "$\\Pr(D_i \\geq D_{max,i})$",
             "(a) Xac suat vi pham tre"),
            (axes[1], "$P_{loss,i}$", "(b) Xac suat mat goi")):
        ax.set_yscale("log")
        ax.set_xticks(x)
        ax.set_xticklabels(names)
        ax.set_xlabel("Access Category (AC)")
        ax.set_ylabel(ylab)
        ax.set_title(title)
        ax.grid(True, which="both", axis="y", color=GRID, linewidth=0.6)
        ax.legend(loc="upper center", ncol=4, bbox_to_anchor=(0.5, 1.0),
                  fontsize=8)

    lo = min(min(d["configs"][n]["violation"]) for n in order)
    axes[0].set_ylim(max(lo * 1e-2, 1e-17), 60.0)
    axes[1].set_ylim(min(min(d["configs"][n]["p_loss"]) for n in order) * 0.2, 20.0)
    feas = {n: d["configs"][n]["feasible"] for n in order}
    fig.text(0.5, -0.04, "thoa man moi rang buoc tre: "
             + ",  ".join(f"{n} = {'co' if v else 'KHONG'}"
                          for n, v in feas.items()),
             ha="center", fontsize=8.5, color=INK_2)

    fig.suptitle("Fig. 5 -- So sanh QoS: EDCA mac dinh, EDCA toi uu va "
                 "MLO EDCA toi uu", fontsize=11, y=1.0)
    fig.tight_layout()
    return save(fig, "fig05_qos_comparison")


# ===========================================================================
# Fig. 6 -- anh huong cua nguong eps_1
# ===========================================================================


def plot_fig6(d: Dict) -> str:
    eps1 = np.array(d["eps1"])
    fig, axes = plt.subplots(1, 2, figsize=(11.0, 4.2))

    for k, tag in enumerate(("EDCA", "MLO EDCA")):
        fit = np.array(d[tag]["fitness"], dtype=float)
        fit = np.where(fit < -500, np.nan, fit)          # ca the vi pham -> bo qua
        axes[0].semilogx(eps1, fit, marker=MARKERS[k], color=CONFIG_COLOR[tag],
                         label=tag, markeredgecolor="white", markeredgewidth=0.7)
        axes[1].semilogx(eps1, d[tag]["sum_theta"], marker=MARKERS[k],
                         color=CONFIG_COLOR[tag], label=tag,
                         markeredgecolor="white", markeredgewidth=0.7)

    axes[1].semilogx(eps1, d["target_sum_theta"], ":", color=MUTED,
                     linewidth=1.6, label="Muc tieu $\\sum_i -\\log_{10}\\epsilon_i$")

    axes[0].set_xlabel("$\\epsilon_1$")
    axes[0].set_ylabel("Gia tri thich nghi")
    axes[0].set_title("(a) Gia tri thich nghi theo $\\epsilon_1$")
    axes[0].legend(loc="best")

    axes[1].set_xlabel("$\\epsilon_1$")
    axes[1].set_ylabel("$\\sum_i \\theta_i$")
    axes[1].set_title("(b) Tong chi so tin cay tre")
    axes[1].legend(loc="best")

    fig.suptitle("Fig. 6 -- Anh huong cua nguong tin cay $\\epsilon_1$ cua AC$_1$",
                 fontsize=11, y=1.0)
    fig.tight_layout()
    return save(fig, "fig06_epsilon_impact")
